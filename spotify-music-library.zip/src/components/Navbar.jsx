export default function Navbar() {
  return (
    <div className="bg-gray-900 p-4 text-xl font-bold">Spotify Clone</div>
  )
}