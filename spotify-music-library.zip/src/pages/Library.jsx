const Library = () => <div className='p-4 text-white'>Your Music Library</div>;
export default Library;