# Spotify Music Library

A simple static React + Tailwind CSS app with routing.
